package com.example.retrovolley;

public class Konfigurasi {
    public String baseUrl() {
        return "http://10.10.4.34/Koneksi/";
    }
}
